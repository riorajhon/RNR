<?php
/**
 * Stripe configuration. Copy this file to config.stripe.php and set your values.
 * Get keys from: Stripe Dashboard → Developers → API keys.
 * Create Payment Links: Stripe Dashboard → Product catalog → Payment links.
 * Use "Switch to sandbox" for test keys (pk_test_... / sk_test_...) and test links.
 */
define('STRIPE_PUBLISHABLE_KEY', 'pk_live_51T3f1oLslLunKXLUdFX9J9ZUaaZfp9xGE5V2q3OjrWXpigVtVwi441VkRSEnlSJsagruOhb2QTEBatm26EiEZHuj00sF0ZcJZ5');  // Publishable key (safe in frontend)
define('STRIPE_SECRET_KEY', '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');       // Secret key — server-side only, never expose
define('STRIPE_MONTHLY_LINK', 'https://buy.stripe.com/dRmeVebfQfIgeIi6rF0oM02');  // $2/month recurring
define('STRIPE_ANNUAL_LINK', 'https://buy.stripe.com/5kQ3cwfw6dA8gQqcQ30oM03');    // $20/year recurring
// One product with two prices: set your single Product ID here. The app picks monthly or yearly price automatically.
define('STRIPE_PRODUCT_ID', 'prod_U1vboaYKrTgTbe');          // Your product ID (one product, two prices: $2/month + $20/year)
define('STRIPE_PRODUCT_ID_MONTHLY', '');          // Leave empty when using STRIPE_PRODUCT_ID above
define('STRIPE_PRODUCT_ID_YEARLY', '');
define('STRIPE_PRICE_ID_MONTHLY', 'price_1T3rk3LslLunKXLU2GvwJb9V');            // Optional: set price_xxx to skip product lookup
define('STRIPE_PRICE_ID_YEARLY', 'price_1T3rkpLslLunKXLU9BVufXgd');
define('STRIPE_WEBHOOK_SECRET', 'whsec_xxx');    // From Stripe → Developers → Webhooks → signing secret
