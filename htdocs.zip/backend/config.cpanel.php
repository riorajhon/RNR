<?php
/**
 * One config for both XAMPP (local) and cPanel (deploy).
 * Toggle CPANEL_DEPLOY: false = local (XAMPP), true = deployed (cPanel).
 */
define('CPANEL_DEPLOY', false);   // false = local (XAMPP) | true = deployed (cPanel)

if (CPANEL_DEPLOY) {
  // --- Deployed (cPanel): live URL, cPanel DB, SMTP ---
  define('SITE_URL', 'https://myratings.online');
  define('DB_HOST', 'localhost');
  define('DB_NAME', 'myraazsn_onetxt');
  define('DB_USER', 'myraazsn');
  define('DB_PASS', 'ztejQ5EJiGQR');
  // Admin: this email can access all pages without a subscription (same as local)
  define('ADMIN_EMAIL', 'riorajhon19930303@gmail.com');
  // Secure SSL/TLS (cPanel Connect Devices): outgoing host myratings.online, port 465, SSL
  define('CONTACT_SMTP_HOST', 'myratings.online');
  define('CONTACT_SMTP_PORT', 465);
  define('CONTACT_SMTP_USER', 'mail@myratings.online');
  define('CONTACT_SMTP_PASS', 'Saikat@123@@@');
  define('CONTACT_SMTP_SECURE', 'ssl');
} else {
  // --- Local (XAMPP): no SITE_URL (uses request URL), optional local DB/SMTP ---
  // Uncomment and set if you use a local DB different from backend/config.php defaults:
  // define('DB_HOST', 'localhost');
  // define('DB_NAME', 'your_local_db');
  // define('DB_USER', 'root');
  // define('DB_PASS', '');
//   SMTP: leave undefined to use PHP mail() or set local test values
}
